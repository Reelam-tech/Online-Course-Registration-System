package onlinecourseregistrationsystemapp1.util;

import onlinecourseregistrationsystemapp1.model.User;

/**
 * Session Manager utility class.
 * Manages the current user session throughout the application.
 */
public class SessionManager {

    private static User currentUser = null;

    /**
     * Private constructor to prevent instantiation
     */
    private SessionManager() {
    }

    /**
     * Sets the current logged-in user.
     *
     * @param user the user to set as current
     */
    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    /**
     * Gets the current logged-in user.
     *
     * @return the current user, or null if not logged in
     */
    public static User getCurrentUser() {
        return currentUser;
    }

    /**
     * Checks if a user is currently logged in.
     *
     * @return true if logged in, false otherwise
     */
    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    /**
     * Gets the current user's ID.
     *
     * @return the user ID, or -1 if not logged in
     */
    public static int getCurrentUserId() {
        return currentUser != null ? currentUser.getUserId() : -1;
    }

    /**
     * Gets the current user's role.
     *
     * @return the role, or null if not logged in
     */
    public static String getCurrentUserRole() {
        return currentUser != null ? currentUser.getRole() : null;
    }

    /**
     * Clears the current session (logout).
     */
    public static void clearSession() {
        currentUser = null;
    }
}
