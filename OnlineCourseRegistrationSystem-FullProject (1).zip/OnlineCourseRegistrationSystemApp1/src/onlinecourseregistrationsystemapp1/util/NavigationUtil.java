package onlinecourseregistrationsystemapp1.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Utility class for navigation between screens.
 */
public class NavigationUtil {

    /**
     * Navigates to a new screen.
     *
     * @param currentStage the current stage
     * @param fxmlPath the path to the FXML file
     * @param title the window title
     */
    public static void navigateTo(Stage currentStage, String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    NavigationUtil.class.getResource(fxmlPath));
            Parent root = loader.load();

            Scene scene = new Scene(root);
            currentStage.setScene(scene);
            currentStage.setTitle(title + " - Online Course Registration System");
            currentStage.centerOnScreen();
        } catch (Exception e) {
            AlertUtil.showError("Navigation Error", "Failed to load screen: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Navigates to the login screen.
     *
     * @param currentStage the current stage
     */
    public static void navigateToLogin(Stage currentStage) {
        SessionManager.clearSession();
        navigateTo(currentStage, "/onlinecourseregistrationsystemapp1/view/Login.fxml", "Login");
    }

    /**
     * Navigates to the appropriate dashboard based on user role.
     *
     * @param currentStage the current stage
     */
    public static void navigateToDashboard(Stage currentStage) {
        String role = SessionManager.getCurrentUserRole();
        if (role == null) {
            navigateToLogin(currentStage);
            return;
        }

        String fxmlPath;
        String title;

        switch (role) {
            case "STUDENT":
                fxmlPath = "/onlinecourseregistrationsystemapp1/view/StudentDashboard.fxml";
                title = "Student Dashboard";
                break;
            case "PROFESSOR":
                fxmlPath = "/onlinecourseregistrationsystemapp1/view/ProfessorDashboard.fxml";
                title = "Professor Dashboard";
                break;
            case "ADMIN":
                fxmlPath = "/onlinecourseregistrationsystemapp1/view/AdminDashboard.fxml";
                title = "Admin Dashboard";
                break;
            default:
                navigateToLogin(currentStage);
                return;
        }

        navigateTo(currentStage, fxmlPath, title);
    }
}
