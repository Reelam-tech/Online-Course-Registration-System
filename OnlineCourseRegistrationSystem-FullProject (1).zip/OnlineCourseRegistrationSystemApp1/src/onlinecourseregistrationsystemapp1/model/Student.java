package onlinecourseregistrationsystemapp1.model;

import java.util.ArrayList;

/**
 * Student class - extends User.
 * Demonstrates inheritance from CS313 course.
 */
public class Student extends User {

    private ArrayList<Enrollment> enrollments;

    /**
     * Default constructor
     */
    public Student() {
        super();
        this.enrollments = new ArrayList<>();
    }

    /**
     * Parameterized constructor
     */
    public Student(int userId, String username, String password,
            String firstName, String lastName, String email) {
        super(userId, username, password, "STUDENT", firstName, lastName, email);
        this.enrollments = new ArrayList<>();
    }

    // Getters and Setters
    public ArrayList<Enrollment> getEnrollments() {
        return enrollments;
    }

    public void setEnrollments(ArrayList<Enrollment> enrollments) {
        this.enrollments = enrollments;
    }

    /**
     * Adds an enrollment to the student's list
     */
    public void addEnrollment(Enrollment enrollment) {
        this.enrollments.add(enrollment);
    }

    /**
     * Removes an enrollment from the student's list
     */
    public void removeEnrollment(Enrollment enrollment) {
        this.enrollments.remove(enrollment);
    }

    /**
     * Gets the number of enrolled courses
     */
    public int getEnrolledCoursesCount() {
        return enrollments.size();
    }

    @Override
    public String getUserDescription() {
        return "Student: " + getFullName() + " - Enrolled in " + getEnrolledCoursesCount() + " courses";
    }

    @Override
    public String toString() {
        return "Student{" + "userId=" + getUserId() + ", name=" + getFullName()
                + ", enrolledCourses=" + getEnrolledCoursesCount() + '}';
    }
}
