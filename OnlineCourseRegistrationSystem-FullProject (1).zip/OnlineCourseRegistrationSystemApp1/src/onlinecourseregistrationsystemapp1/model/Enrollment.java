package onlinecourseregistrationsystemapp1.model;

import java.util.Date;

/**
 * Enrollment class - demonstrates Composition.
 * Contains references to Student and Course (composition).
 */
public class Enrollment {

    private int enrollmentId;
    private int studentId;
    private int courseId;
    private Date enrollmentDate;

    // Composition - for display purposes
    private String studentName;
    private String courseCode;
    private String courseName;

    /**
     * Default constructor
     */
    public Enrollment() {
    }

    /**
     * Parameterized constructor
     */
    public Enrollment(int enrollmentId, int studentId, int courseId, Date enrollmentDate) {
        this.enrollmentId = enrollmentId;
        this.studentId = studentId;
        this.courseId = courseId;
        this.enrollmentDate = enrollmentDate;
    }

    // Getters and Setters
    public int getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(int enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public Date getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(Date enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    @Override
    public String toString() {
        return "Enrollment{" + "enrollmentId=" + enrollmentId
                + ", studentId=" + studentId + ", courseId=" + courseId
                + ", enrollmentDate=" + enrollmentDate + '}';
    }
}
