package onlinecourseregistrationsystemapp1.model;

import java.util.ArrayList;

/**
 * Professor class - extends User.
 * Demonstrates inheritance from CS313 course.
 */
public class Professor extends User {

    private ArrayList<Course> assignedCourses;

    /**
     * Default constructor
     */
    public Professor() {
        super();
        this.assignedCourses = new ArrayList<>();
    }

    /**
     * Parameterized constructor
     */
    public Professor(int userId, String username, String password,
            String firstName, String lastName, String email) {
        super(userId, username, password, "PROFESSOR", firstName, lastName, email);
        this.assignedCourses = new ArrayList<>();
    }

    // Getters and Setters
    public ArrayList<Course> getAssignedCourses() {
        return assignedCourses;
    }

    public void setAssignedCourses(ArrayList<Course> assignedCourses) {
        this.assignedCourses = assignedCourses;
    }

    /**
     * Adds a course to the professor's assigned courses
     */
    public void addCourse(Course course) {
        this.assignedCourses.add(course);
    }

    /**
     * Removes a course from the professor's assigned courses
     */
    public void removeCourse(Course course) {
        this.assignedCourses.remove(course);
    }

    /**
     * Gets the number of assigned courses
     */
    public int getAssignedCoursesCount() {
        return assignedCourses.size();
    }

    @Override
    public String getUserDescription() {
        return "Professor: " + getFullName() + " - Teaching " + getAssignedCoursesCount() + " courses";
    }

    @Override
    public String toString() {
        return "Professor{" + "userId=" + getUserId() + ", name=" + getFullName()
                + ", assignedCourses=" + getAssignedCoursesCount() + '}';
    }
}
