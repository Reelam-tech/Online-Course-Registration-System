package onlinecourseregistrationsystemapp1.model;

/**
 * Admin class - extends User.
 * Demonstrates inheritance from CS313 course.
 */
public class Admin extends User {

    /**
     * Default constructor
     */
    public Admin() {
        super();
    }

    /**
     * Parameterized constructor
     */
    public Admin(int userId, String username, String password,
            String firstName, String lastName, String email) {
        super(userId, username, password, "ADMIN", firstName, lastName, email);
    }

    @Override
    public String getUserDescription() {
        return "Administrator: " + getFullName() + " - System Management";
    }

    @Override
    public String toString() {
        return "Admin{" + "userId=" + getUserId() + ", name=" + getFullName() + '}';
    }
}
