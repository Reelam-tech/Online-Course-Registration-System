package onlinecourseregistrationsystemapp1.model;

/**
 * Course class - demonstrates Comparable interface and Composition.
 * Implements Comparable for sorting courses by course code.
 */
public class Course implements Comparable<Course> {

    private int courseId;
    private String courseCode;
    private String courseName;
    private String description;
    private int credits;
    private int capacity;
    private int professorId;
    private String professorName; // For display purposes (composition)
    private boolean isOpen;
    private int enrolledCount; // Number of enrolled students

    /**
     * Default constructor
     */
    public Course() {
    }

    /**
     * Parameterized constructor
     */
    public Course(int courseId, String courseCode, String courseName,
            String description, int credits, int capacity, int professorId, boolean isOpen) {
        this.courseId = courseId;
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.description = description;
        this.credits = credits;
        this.capacity = capacity;
        this.professorId = professorId;
        this.isOpen = isOpen;
        this.enrolledCount = 0;
    }

    // Getters and Setters
    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getProfessorId() {
        return professorId;
    }

    public void setProfessorId(int professorId) {
        this.professorId = professorId;
    }

    public String getProfessorName() {
        return professorName;
    }

    public void setProfessorName(String professorName) {
        this.professorName = professorName;
    }

    public boolean isIsOpen() {
        return isOpen;
    }

    public void setIsOpen(boolean isOpen) {
        this.isOpen = isOpen;
    }

    public int getEnrolledCount() {
        return enrolledCount;
    }

    public void setEnrolledCount(int enrolledCount) {
        this.enrolledCount = enrolledCount;
    }

    /**
     * Checks if the course has available seats
     */
    public boolean hasAvailableSeats() {
        return enrolledCount < capacity;
    }

    /**
     * Gets available seats count
     */
    public int getAvailableSeats() {
        return capacity - enrolledCount;
    }

    /**
     * Gets status string for display
     */
    public String getStatus() {
        if (!isOpen) {
            return "Closed";
        } else if (!hasAvailableSeats()) {
            return "Full";
        } else {
            return "Open";
        }
    }

    /**
     * Implements Comparable interface for sorting by course code
     */
    @Override
    public int compareTo(Course other) {
        return this.courseCode.compareTo(other.courseCode);
    }

    @Override
    public String toString() {
        return "Course{" + "courseCode=" + courseCode + ", courseName=" + courseName
                + ", credits=" + credits + ", capacity=" + capacity
                + ", enrolled=" + enrolledCount + ", isOpen=" + isOpen + '}';
    }
}
