package onlinecourseregistrationsystemapp1.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import onlinecourseregistrationsystemapp1.dao.CourseDAO;
import onlinecourseregistrationsystemapp1.dao.EnrollmentDAO;
import onlinecourseregistrationsystemapp1.model.Course;
import onlinecourseregistrationsystemapp1.model.User;
import onlinecourseregistrationsystemapp1.util.SessionManager;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller for the Student Dashboard.
 */
public class StudentDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private VBox contentArea;

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        currentUser = SessionManager.getCurrentUser();
        if (currentUser != null) {
            welcomeLabel.setText("Welcome, " + currentUser.getFullName());
        }
    }

    /**
     * Shows the available courses for registration.
     */
    @FXML
    private void showAvailableCourses(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("Available Courses");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create table
        TableView<Course> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Define columns
        TableColumn<Course, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));

        TableColumn<Course, String> nameCol = new TableColumn<>("Course Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("courseName"));

        TableColumn<Course, Integer> creditsCol = new TableColumn<>("Credits");
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("credits"));

        TableColumn<Course, String> profCol = new TableColumn<>("Professor");
        profCol.setCellValueFactory(new PropertyValueFactory<>("professorName"));

        TableColumn<Course, Integer> availableCol = new TableColumn<>("Available Seats");
        availableCol.setCellValueFactory(new PropertyValueFactory<>("availableSeats"));

        table.getColumns().addAll(codeCol, nameCol, creditsCol, profCol, availableCol);

        // Load data
        ArrayList<Course> courses = courseDAO.getAvailableCourses();
        // Filter out courses already enrolled
        ArrayList<Course> enrolledCourses = enrollmentDAO.getEnrolledCourses(currentUser.getUserId());
        courses.removeIf(course -> {
            for (Course enrolled : enrolledCourses) {
                if (enrolled.getCourseId() == course.getCourseId()) {
                    return true;
                }
            }
            return false;
        });

        ObservableList<Course> data = FXCollections.observableArrayList(courses);
        table.setItems(data);

        // Register button
        Button registerBtn = new Button("Register for Selected Course");
        registerBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                boolean success = enrollmentDAO.enrollStudent(currentUser.getUserId(), selected.getCourseId());
                if (success) {
                    showAlert(Alert.AlertType.INFORMATION, "Success",
                            "Successfully registered for " + selected.getCourseCode());
                    showAvailableCourses(null); // Refresh
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error",
                            "Failed to register for course.");
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning",
                        "Please select a course to register.");
            }
        });

        contentArea.getChildren().addAll(title, table, registerBtn);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows the student's enrolled courses (My Schedule).
     */
    @FXML
    private void showMySchedule(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("My Schedule");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create table
        TableView<Course> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Define columns
        TableColumn<Course, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));

        TableColumn<Course, String> nameCol = new TableColumn<>("Course Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("courseName"));

        TableColumn<Course, Integer> creditsCol = new TableColumn<>("Credits");
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("credits"));

        TableColumn<Course, String> profCol = new TableColumn<>("Professor");
        profCol.setCellValueFactory(new PropertyValueFactory<>("professorName"));

        TableColumn<Course, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        table.getColumns().addAll(codeCol, nameCol, creditsCol, profCol, statusCol);

        // Load data
        ArrayList<Course> courses = enrollmentDAO.getEnrolledCourses(currentUser.getUserId());
        ObservableList<Course> data = FXCollections.observableArrayList(courses);
        table.setItems(data);

        // Drop button
        Button dropBtn = new Button("Drop Selected Course");
        dropBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                // Confirmation dialog
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                confirm.setTitle("Confirm Drop");
                confirm.setHeaderText("Drop Course");
                confirm.setContentText("Are you sure you want to drop " + selected.getCourseCode() + "?");

                if (confirm.showAndWait().get() == ButtonType.OK) {
                    boolean success = enrollmentDAO.dropCourse(currentUser.getUserId(), selected.getCourseId());
                    if (success) {
                        showAlert(Alert.AlertType.INFORMATION, "Success",
                                "Successfully dropped " + selected.getCourseCode());
                        showMySchedule(null); // Refresh
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Error",
                                "Failed to drop course.");
                    }
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning",
                        "Please select a course to drop.");
            }
        });

        // Total credits
        int totalCredits = courses.stream().mapToInt(Course::getCredits).sum();
        Label creditsLabel = new Label("Total Credits: " + totalCredits);
        creditsLabel.setStyle("-fx-font-weight: bold;");

        contentArea.getChildren().addAll(title, table, dropBtn, creditsLabel);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Handles logout.
     */
    @FXML
    private void handleLogout(ActionEvent event) {
        Stage stage = (Stage) welcomeLabel.getScene().getWindow();
        LoginController.logout(stage);
    }

    /**
     * Shows an alert dialog.
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
