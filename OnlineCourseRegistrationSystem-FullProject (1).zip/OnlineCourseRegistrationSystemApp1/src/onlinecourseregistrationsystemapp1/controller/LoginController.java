package onlinecourseregistrationsystemapp1.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import onlinecourseregistrationsystemapp1.dao.UserDAO;
import onlinecourseregistrationsystemapp1.model.User;
import onlinecourseregistrationsystemapp1.util.NavigationUtil;
import onlinecourseregistrationsystemapp1.util.SessionManager;

/**
 * Controller for the Login screen.
 */
public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    private UserDAO userDAO = new UserDAO();

    /**
     * Gets the currently logged-in user.
     * @deprecated Use SessionManager.getCurrentUser() instead
     */
    @Deprecated
    public static User getCurrentUser() {
        return SessionManager.getCurrentUser();
    }

    /**
     * Handles the login button click.
     */
    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please enter username and password.");
            return;
        }

        try {
            // Authenticate user
            User user = userDAO.authenticate(username, password);

            if (user != null) {
                // Set session
                SessionManager.setCurrentUser(user);
                errorLabel.setText("");

                // Navigate to appropriate dashboard
                Stage stage = (Stage) usernameField.getScene().getWindow();
                NavigationUtil.navigateToDashboard(stage);

            } else {
                errorLabel.setText("Invalid username or password.");
            }
        } catch (Exception e) {
            errorLabel.setText("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Handles the clear button click.
     */
    @FXML
    private void handleClear(ActionEvent event) {
        usernameField.clear();
        passwordField.clear();
        errorLabel.setText("");
        usernameField.requestFocus();
    }

    /**
     * Static method to logout and return to login screen.
     */
    public static void logout(Stage currentStage) {
        NavigationUtil.navigateToLogin(currentStage);
    }
}
