package onlinecourseregistrationsystemapp1.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import onlinecourseregistrationsystemapp1.dao.CourseDAO;
import onlinecourseregistrationsystemapp1.dao.EnrollmentDAO;
import onlinecourseregistrationsystemapp1.model.Course;
import onlinecourseregistrationsystemapp1.model.Enrollment;
import onlinecourseregistrationsystemapp1.model.User;
import onlinecourseregistrationsystemapp1.util.SessionManager;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller for the Professor Dashboard.
 */
public class ProfessorDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private VBox contentArea;

    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;
    private Course selectedCourse;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        currentUser = SessionManager.getCurrentUser();
        if (currentUser != null) {
            welcomeLabel.setText("Welcome, " + currentUser.getFullName());
        }
    }

    /**
     * Shows the professor's courses.
     */
    @FXML
    private void showMyCourses(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("My Courses");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create table
        TableView<Course> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Define columns
        TableColumn<Course, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));

        TableColumn<Course, String> nameCol = new TableColumn<>("Course Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("courseName"));

        TableColumn<Course, Integer> creditsCol = new TableColumn<>("Credits");
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("credits"));

        TableColumn<Course, Integer> capacityCol = new TableColumn<>("Capacity");
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        TableColumn<Course, Integer> enrolledCol = new TableColumn<>("Enrolled");
        enrolledCol.setCellValueFactory(new PropertyValueFactory<>("enrolledCount"));

        TableColumn<Course, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        table.getColumns().addAll(codeCol, nameCol, creditsCol, capacityCol, enrolledCol, statusCol);

        // Load data
        ArrayList<Course> courses = courseDAO.getCoursesByProfessor(currentUser.getUserId());
        ObservableList<Course> data = FXCollections.observableArrayList(courses);
        table.setItems(data);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button updateBtn = new Button("Update Course");
        updateBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showUpdateCourseForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a course to update.");
            }
        });

        Button toggleBtn = new Button("Toggle Open/Close");
        toggleBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                selected.setIsOpen(!selected.isIsOpen());
                boolean success = courseDAO.updateCourse(selected);
                if (success) {
                    showAlert(Alert.AlertType.INFORMATION, "Success",
                            "Course " + (selected.isIsOpen() ? "opened" : "closed") + " successfully.");
                    showMyCourses(null);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update course.");
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a course.");
            }
        });

        buttonBox.getChildren().addAll(updateBtn, toggleBtn);

        contentArea.getChildren().addAll(title, table, buttonBox);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows the update course form.
     */
    private void showUpdateCourseForm(Course course) {
        contentArea.getChildren().clear();

        Label title = new Label("Update Course: " + course.getCourseCode());
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        // Course Name
        Label nameLabel = new Label("Course Name:");
        TextField nameField = new TextField(course.getCourseName());
        form.add(nameLabel, 0, 0);
        form.add(nameField, 1, 0);

        // Description
        Label descLabel = new Label("Description:");
        TextArea descField = new TextArea(course.getDescription());
        descField.setPrefRowCount(3);
        form.add(descLabel, 0, 1);
        form.add(descField, 1, 1);

        // Capacity
        Label capacityLabel = new Label("Capacity:");
        TextField capacityField = new TextField(String.valueOf(course.getCapacity()));
        form.add(capacityLabel, 0, 2);
        form.add(capacityField, 1, 2);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            try {
                course.setCourseName(nameField.getText().trim());
                course.setDescription(descField.getText().trim());
                course.setCapacity(Integer.parseInt(capacityField.getText().trim()));

                boolean success = courseDAO.updateCourse(course);
                if (success) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Course updated successfully.");
                    showMyCourses(null);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update course.");
                }
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please enter a valid capacity.");
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> showMyCourses(null));

        buttonBox.getChildren().addAll(saveBtn, cancelBtn);

        contentArea.getChildren().addAll(title, form, buttonBox);
        VBox.setMargin(form, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows students enrolled in professor's courses.
     */
    @FXML
    private void showEnrolledStudents(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("View Enrolled Students");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Course selection
        Label selectLabel = new Label("Select Course:");
        ComboBox<Course> courseCombo = new ComboBox<>();
        ArrayList<Course> courses = courseDAO.getCoursesByProfessor(currentUser.getUserId());
        courseCombo.setItems(FXCollections.observableArrayList(courses));
        courseCombo.setCellFactory(param -> new ListCell<Course>() {
            @Override
            protected void updateItem(Course item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getCourseCode() + " - " + item.getCourseName());
                }
            }
        });
        courseCombo.setButtonCell(new ListCell<Course>() {
            @Override
            protected void updateItem(Course item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getCourseCode() + " - " + item.getCourseName());
                }
            }
        });

        HBox selectBox = new HBox(10);
        selectBox.getChildren().addAll(selectLabel, courseCombo);

        // Students table
        TableView<Enrollment> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Enrollment, Integer> idCol = new TableColumn<>("Student ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("studentId"));

        TableColumn<Enrollment, String> nameCol = new TableColumn<>("Student Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("studentName"));

        TableColumn<Enrollment, String> dateCol = new TableColumn<>("Enrollment Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("enrollmentDate"));

        table.getColumns().addAll(idCol, nameCol, dateCol);

        // Count label
        Label countLabel = new Label("Total Students: 0");

        // Course selection handler
        courseCombo.setOnAction(e -> {
            Course selected = courseCombo.getValue();
            if (selected != null) {
                ArrayList<Enrollment> enrollments = enrollmentDAO.getEnrollmentsByCourse(selected.getCourseId());
                table.setItems(FXCollections.observableArrayList(enrollments));
                countLabel.setText("Total Students: " + enrollments.size());
            }
        });

        contentArea.getChildren().addAll(title, selectBox, table, countLabel);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Handles logout.
     */
    @FXML
    private void handleLogout(ActionEvent event) {
        Stage stage = (Stage) welcomeLabel.getScene().getWindow();
        LoginController.logout(stage);
    }

    /**
     * Shows an alert dialog.
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
