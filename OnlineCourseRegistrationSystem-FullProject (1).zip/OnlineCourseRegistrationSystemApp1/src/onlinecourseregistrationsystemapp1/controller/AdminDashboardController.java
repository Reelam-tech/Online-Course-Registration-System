package onlinecourseregistrationsystemapp1.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import onlinecourseregistrationsystemapp1.dao.CourseDAO;
import onlinecourseregistrationsystemapp1.dao.EnrollmentDAO;
import onlinecourseregistrationsystemapp1.dao.UserDAO;
import onlinecourseregistrationsystemapp1.model.*;
import onlinecourseregistrationsystemapp1.util.SessionManager;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

/**
 * Controller for the Admin Dashboard.
 */
public class AdminDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private VBox contentArea;

    private UserDAO userDAO = new UserDAO();
    private CourseDAO courseDAO = new CourseDAO();
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private User currentUser;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        currentUser = SessionManager.getCurrentUser();
        if (currentUser != null) {
            welcomeLabel.setText("Welcome, " + currentUser.getFullName());
        }
    }

    /**
     * Shows user management screen.
     */
    @FXML
    private void showUserManagement(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("User Management");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create table
        TableView<User> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("userId"));

        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<User, String> nameCol = new TableColumn<>("Full Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        TableColumn<User, String> roleCol = new TableColumn<>("Role");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));

        TableColumn<User, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));

        table.getColumns().addAll(idCol, usernameCol, nameCol, roleCol, emailCol);

        // Load data
        ArrayList<User> users = userDAO.getAllUsers();
        ObservableList<User> data = FXCollections.observableArrayList(users);
        table.setItems(data);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addBtn = new Button("Add User");
        addBtn.setOnAction(e -> showUserForm(null));

        Button editBtn = new Button("Edit User");
        editBtn.setOnAction(e -> {
            User selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showUserForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a user to edit.");
            }
        });

        Button deleteBtn = new Button("Delete User");
        deleteBtn.setOnAction(e -> {
            User selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                if (selected.getUserId() == currentUser.getUserId()) {
                    showAlert(Alert.AlertType.ERROR, "Error", "You cannot delete yourself!");
                    return;
                }
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                confirm.setTitle("Confirm Delete");
                confirm.setHeaderText("Delete User");
                confirm.setContentText("Are you sure you want to delete " + selected.getUsername() + "?");

                if (confirm.showAndWait().get() == ButtonType.OK) {
                    // Delete enrollments first if student
                    if (selected.getRole().equals("STUDENT")) {
                        enrollmentDAO.deleteEnrollmentsByStudent(selected.getUserId());
                    }
                    boolean success = userDAO.deleteUser(selected.getUserId());
                    if (success) {
                        showAlert(Alert.AlertType.INFORMATION, "Success", "User deleted successfully.");
                        showUserManagement(null);
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete user.");
                    }
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a user to delete.");
            }
        });

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        contentArea.getChildren().addAll(title, table, buttonBox);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows the user add/edit form.
     */
    private void showUserForm(User user) {
        contentArea.getChildren().clear();

        boolean isEdit = (user != null);
        Label title = new Label(isEdit ? "Edit User" : "Add New User");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        // Username
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField(isEdit ? user.getUsername() : "");
        form.add(usernameLabel, 0, 0);
        form.add(usernameField, 1, 0);

        // Password
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        if (isEdit) passwordField.setText(user.getPassword());
        form.add(passwordLabel, 0, 1);
        form.add(passwordField, 1, 1);

        // Role
        Label roleLabel = new Label("Role:");
        ComboBox<String> roleCombo = new ComboBox<>();
        roleCombo.setItems(FXCollections.observableArrayList("STUDENT", "PROFESSOR", "ADMIN"));
        if (isEdit) roleCombo.setValue(user.getRole());
        form.add(roleLabel, 0, 2);
        form.add(roleCombo, 1, 2);

        // First Name
        Label firstNameLabel = new Label("First Name:");
        TextField firstNameField = new TextField(isEdit ? user.getFirstName() : "");
        form.add(firstNameLabel, 0, 3);
        form.add(firstNameField, 1, 3);

        // Last Name
        Label lastNameLabel = new Label("Last Name:");
        TextField lastNameField = new TextField(isEdit ? user.getLastName() : "");
        form.add(lastNameLabel, 0, 4);
        form.add(lastNameField, 1, 4);

        // Email
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField(isEdit ? user.getEmail() : "");
        form.add(emailLabel, 0, 5);
        form.add(emailField, 1, 5);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            // Validate
            if (usernameField.getText().trim().isEmpty() ||
                    passwordField.getText().isEmpty() ||
                    roleCombo.getValue() == null ||
                    firstNameField.getText().trim().isEmpty() ||
                    lastNameField.getText().trim().isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please fill all required fields.");
                return;
            }

            User newUser;
            String role = roleCombo.getValue();
            switch (role) {
                case "STUDENT":
                    newUser = new Student();
                    break;
                case "PROFESSOR":
                    newUser = new Professor();
                    break;
                default:
                    newUser = new Admin();
            }

            if (isEdit) newUser.setUserId(user.getUserId());
            newUser.setUsername(usernameField.getText().trim());
            newUser.setPassword(passwordField.getText());
            newUser.setRole(role);
            newUser.setFirstName(firstNameField.getText().trim());
            newUser.setLastName(lastNameField.getText().trim());
            newUser.setEmail(emailField.getText().trim());

            boolean success;
            if (isEdit) {
                success = userDAO.updateUser(newUser);
            } else {
                if (userDAO.usernameExists(newUser.getUsername())) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Username already exists.");
                    return;
                }
                success = userDAO.addUser(newUser);
            }

            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Success",
                        "User " + (isEdit ? "updated" : "added") + " successfully.");
                showUserManagement(null);
            } else {
                showAlert(Alert.AlertType.ERROR, "Error",
                        "Failed to " + (isEdit ? "update" : "add") + " user.");
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> showUserManagement(null));

        buttonBox.getChildren().addAll(saveBtn, cancelBtn);

        contentArea.getChildren().addAll(title, form, buttonBox);
        VBox.setMargin(form, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows course management screen.
     */
    @FXML
    private void showCourseManagement(ActionEvent event) {
        contentArea.getChildren().clear();

        Label title = new Label("Course Management");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Create table
        TableView<Course> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Course, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("courseCode"));

        TableColumn<Course, String> nameCol = new TableColumn<>("Course Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("courseName"));

        TableColumn<Course, Integer> creditsCol = new TableColumn<>("Credits");
        creditsCol.setCellValueFactory(new PropertyValueFactory<>("credits"));

        TableColumn<Course, String> profCol = new TableColumn<>("Professor");
        profCol.setCellValueFactory(new PropertyValueFactory<>("professorName"));

        TableColumn<Course, Integer> capacityCol = new TableColumn<>("Capacity");
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        TableColumn<Course, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        table.getColumns().addAll(codeCol, nameCol, creditsCol, profCol, capacityCol, statusCol);

        // Load data
        ArrayList<Course> courses = courseDAO.getAllCourses();
        ObservableList<Course> data = FXCollections.observableArrayList(courses);
        table.setItems(data);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button addBtn = new Button("Add Course");
        addBtn.setOnAction(e -> showCourseForm(null));

        Button editBtn = new Button("Edit Course");
        editBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                showCourseForm(selected);
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a course to edit.");
            }
        });

        Button deleteBtn = new Button("Delete Course");
        deleteBtn.setOnAction(e -> {
            Course selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
                confirm.setTitle("Confirm Delete");
                confirm.setHeaderText("Delete Course");
                confirm.setContentText("Are you sure you want to delete " + selected.getCourseCode() + "?\n"
                        + "This will also remove all enrollments.");

                if (confirm.showAndWait().get() == ButtonType.OK) {
                    enrollmentDAO.deleteEnrollmentsByCourse(selected.getCourseId());
                    boolean success = courseDAO.deleteCourse(selected.getCourseId());
                    if (success) {
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Course deleted successfully.");
                        showCourseManagement(null);
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete course.");
                    }
                }
            } else {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please select a course to delete.");
            }
        });

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        contentArea.getChildren().addAll(title, table, buttonBox);
        VBox.setMargin(table, new Insets(10, 0, 10, 0));
    }

    /**
     * Shows the course add/edit form.
     */
    private void showCourseForm(Course course) {
        contentArea.getChildren().clear();

        boolean isEdit = (course != null);
        Label title = new Label(isEdit ? "Edit Course" : "Add New Course");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(10);

        // Course Code
        Label codeLabel = new Label("Course Code:");
        TextField codeField = new TextField(isEdit ? course.getCourseCode() : "");
        form.add(codeLabel, 0, 0);
        form.add(codeField, 1, 0);

        // Course Name
        Label nameLabel = new Label("Course Name:");
        TextField nameField = new TextField(isEdit ? course.getCourseName() : "");
        form.add(nameLabel, 0, 1);
        form.add(nameField, 1, 1);

        // Description
        Label descLabel = new Label("Description:");
        TextArea descField = new TextArea(isEdit ? course.getDescription() : "");
        descField.setPrefRowCount(2);
        form.add(descLabel, 0, 2);
        form.add(descField, 1, 2);

        // Credits
        Label creditsLabel = new Label("Credits:");
        TextField creditsField = new TextField(isEdit ? String.valueOf(course.getCredits()) : "");
        form.add(creditsLabel, 0, 3);
        form.add(creditsField, 1, 3);

        // Capacity
        Label capacityLabel = new Label("Capacity:");
        TextField capacityField = new TextField(isEdit ? String.valueOf(course.getCapacity()) : "");
        form.add(capacityLabel, 0, 4);
        form.add(capacityField, 1, 4);

        // Professor
        Label profLabel = new Label("Professor:");
        ComboBox<User> profCombo = new ComboBox<>();
        ArrayList<User> professors = userDAO.getAllProfessors();
        profCombo.setItems(FXCollections.observableArrayList(professors));
        profCombo.setCellFactory(param -> new ListCell<User>() {
            @Override
            protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getFullName());
            }
        });
        profCombo.setButtonCell(new ListCell<User>() {
            @Override
            protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getFullName());
            }
        });
        if (isEdit) {
            for (User prof : professors) {
                if (prof.getUserId() == course.getProfessorId()) {
                    profCombo.setValue(prof);
                    break;
                }
            }
        }
        form.add(profLabel, 0, 5);
        form.add(profCombo, 1, 5);

        // Is Open
        Label openLabel = new Label("Status:");
        CheckBox openCheck = new CheckBox("Open for Registration");
        openCheck.setSelected(isEdit ? course.isIsOpen() : true);
        form.add(openLabel, 0, 6);
        form.add(openCheck, 1, 6);

        // Buttons
        HBox buttonBox = new HBox(10);
        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            try {
                // Validate
                if (codeField.getText().trim().isEmpty() ||
                        nameField.getText().trim().isEmpty() ||
                        creditsField.getText().trim().isEmpty() ||
                        capacityField.getText().trim().isEmpty() ||
                        profCombo.getValue() == null) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Please fill all required fields.");
                    return;
                }

                int credits = Integer.parseInt(creditsField.getText().trim());
                int capacity = Integer.parseInt(capacityField.getText().trim());

                if (credits < 1 || credits > 4) {
                    showAlert(Alert.AlertType.ERROR, "Error", "Credits must be between 1 and 4.");
                    return;
                }

                Course newCourse = new Course();
                if (isEdit) newCourse.setCourseId(course.getCourseId());
                newCourse.setCourseCode(codeField.getText().trim());
                newCourse.setCourseName(nameField.getText().trim());
                newCourse.setDescription(descField.getText().trim());
                newCourse.setCredits(credits);
                newCourse.setCapacity(capacity);
                newCourse.setProfessorId(profCombo.getValue().getUserId());
                newCourse.setIsOpen(openCheck.isSelected());

                boolean success;
                if (isEdit) {
                    success = courseDAO.updateCourse(newCourse);
                } else {
                    if (courseDAO.courseCodeExists(newCourse.getCourseCode())) {
                        showAlert(Alert.AlertType.ERROR, "Error", "Course code already exists.");
                        return;
                    }
                    success = courseDAO.addCourse(newCourse);
                }

                if (success) {
                    showAlert(Alert.AlertType.INFORMATION, "Success",
                            "Course " + (isEdit ? "updated" : "added") + " successfully.");
                    showCourseManagement(null);
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error",
                            "Failed to " + (isEdit ? "update" : "add") + " course.");
                }
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Error", "Please enter valid numbers for credits and capacity.");
            }
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> showCourseManagement(null));

        buttonBox.getChildren().addAll(saveBtn, cancelBtn);

        contentArea.getChildren().addAll(title, form, buttonBox);
        VBox.setMargin(form, new Insets(10, 0, 10, 0));
    }

    /**
     * Handles logout.
     */
    @FXML
    private void handleLogout(ActionEvent event) {
        Stage stage = (Stage) welcomeLabel.getScene().getWindow();
        LoginController.logout(stage);
    }

    /**
     * Shows an alert dialog.
     */
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
