package onlinecourseregistrationsystemapp1.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Database Connection utility class for Oracle database.
 * Provides singleton connection to the database.
 *
 * Connection URL formats:
 * - SID format: jdbc:oracle:thin:@hostname:port:SID
 * - Service Name format: jdbc:oracle:thin:@//hostname:port/serviceName
 */
public class DatabaseConnection {

    // Database credentials - Update these according to your Oracle setup
    // For SID: jdbc:oracle:thin:@localhost:1521:orcl12
    // For Service Name: jdbc:oracle:thin:@//localhost:1521/orcl12
    private static final String URL = "jdbc:oracle:thin:@//localhost:1521/orcl12";
    private static final String USERNAME = "system";
    private static final String PASSWORD = "1234";

    // Singleton instance
    private static Connection connection = null;

    /**
     * Private constructor to prevent instantiation
     */
    private DatabaseConnection() {
    }

    /**
     * Gets the database connection.
     * Creates a new connection if one doesn't exist.
     *
     * @return Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        try {
            if (connection == null || connection.isClosed()) {
                // Load Oracle JDBC driver
                Class.forName("oracle.jdbc.driver.OracleDriver");

                // Establish connection
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                System.out.println("Database connection established successfully.");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Oracle JDBC Driver not found!");
            throw new SQLException("Oracle JDBC Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Database connection failed!");
            throw e;
        }
        return connection;
    }

    /**
     * Closes the database connection.
     */
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing database connection: " + e.getMessage());
        }
    }

    /**
     * Tests the database connection.
     *
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        try {
            Connection conn = getConnection();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("Connection test failed: " + e.getMessage());
            return false;
        }
    }
}
