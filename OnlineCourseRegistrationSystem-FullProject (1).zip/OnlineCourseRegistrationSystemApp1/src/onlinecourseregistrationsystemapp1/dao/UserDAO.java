package onlinecourseregistrationsystemapp1.dao;

import onlinecourseregistrationsystemapp1.model.*;
import java.sql.*;
import java.util.ArrayList;

/**
 * Data Access Object for User operations.
 * Handles all database operations related to users.
 */
public class UserDAO {

    /**
     * Authenticates a user with username and password.
     *
     * @param username the username
     * @param password the password
     * @return User object if authentication successful, null otherwise
     */
    public User authenticate(String username, String password) {
        String sql = "SELECT * FROM USERS WHERE username = ? AND password = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Authentication error: " + e.getMessage());
        }
        return null;
    }

    /**
     * Gets all users from the database.
     *
     * @return ArrayList of all users
     */
    public ArrayList<User> getAllUsers() {
        ArrayList<User> users = new ArrayList<>();
        String sql = "SELECT * FROM USERS ORDER BY user_id";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                users.add(createUserFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting all users: " + e.getMessage());
        }
        return users;
    }

    /**
     * Gets a user by ID.
     *
     * @param userId the user ID
     * @return User object if found, null otherwise
     */
    public User getUserById(int userId) {
        String sql = "SELECT * FROM USERS WHERE user_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createUserFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting user by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Gets all professors from the database.
     *
     * @return ArrayList of professors
     */
    public ArrayList<User> getAllProfessors() {
        ArrayList<User> professors = new ArrayList<>();
        String sql = "SELECT * FROM USERS WHERE role = 'PROFESSOR' ORDER BY last_name";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                professors.add(createUserFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting professors: " + e.getMessage());
        }
        return professors;
    }

    /**
     * Gets all students from the database.
     *
     * @return ArrayList of students
     */
    public ArrayList<User> getAllStudents() {
        ArrayList<User> students = new ArrayList<>();
        String sql = "SELECT * FROM USERS WHERE role = 'STUDENT' ORDER BY last_name";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                students.add(createUserFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting students: " + e.getMessage());
        }
        return students;
    }

    /**
     * Adds a new user to the database.
     *
     * @param user the user to add
     * @return true if successful, false otherwise
     */
    public boolean addUser(User user) {
        String sql = "INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email) "
                + "VALUES (user_seq.NEXTVAL, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getRole());
            pstmt.setString(4, user.getFirstName());
            pstmt.setString(5, user.getLastName());
            pstmt.setString(6, user.getEmail());

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error adding user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates an existing user in the database.
     *
     * @param user the user to update
     * @return true if successful, false otherwise
     */
    public boolean updateUser(User user) {
        String sql = "UPDATE USERS SET username = ?, password = ?, role = ?, "
                + "first_name = ?, last_name = ?, email = ? WHERE user_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getRole());
            pstmt.setString(4, user.getFirstName());
            pstmt.setString(5, user.getLastName());
            pstmt.setString(6, user.getEmail());
            pstmt.setInt(7, user.getUserId());

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a user from the database.
     *
     * @param userId the user ID to delete
     * @return true if successful, false otherwise
     */
    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM USERS WHERE user_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a username already exists.
     *
     * @param username the username to check
     * @return true if exists, false otherwise
     */
    public boolean usernameExists(String username) {
        String sql = "SELECT COUNT(*) FROM USERS WHERE username = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking username: " + e.getMessage());
        }
        return false;
    }

    /**
     * Creates a User object from ResultSet based on role.
     */
    private User createUserFromResultSet(ResultSet rs) throws SQLException {
        String role = rs.getString("role");
        int userId = rs.getInt("user_id");
        String username = rs.getString("username");
        String password = rs.getString("password");
        String firstName = rs.getString("first_name");
        String lastName = rs.getString("last_name");
        String email = rs.getString("email");

        User user;
        switch (role) {
            case "STUDENT":
                user = new Student(userId, username, password, firstName, lastName, email);
                break;
            case "PROFESSOR":
                user = new Professor(userId, username, password, firstName, lastName, email);
                break;
            case "ADMIN":
                user = new Admin(userId, username, password, firstName, lastName, email);
                break;
            default:
                throw new SQLException("Unknown user role: " + role);
        }
        return user;
    }
}
