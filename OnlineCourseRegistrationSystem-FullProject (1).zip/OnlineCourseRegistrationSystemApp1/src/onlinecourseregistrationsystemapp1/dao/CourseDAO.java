package onlinecourseregistrationsystemapp1.dao;

import onlinecourseregistrationsystemapp1.model.Course;
import java.sql.*;
import java.util.ArrayList;

/**
 * Data Access Object for Course operations.
 * Handles all database operations related to courses.
 */
public class CourseDAO {

    /**
     * Gets all courses from the database.
     *
     * @return ArrayList of all courses
     */
    public ArrayList<Course> getAllCourses() {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, u.first_name || ' ' || u.last_name as professor_name, "
                + "(SELECT COUNT(*) FROM ENROLLMENTS e WHERE e.course_id = c.course_id) as enrolled_count "
                + "FROM COURSES c LEFT JOIN USERS u ON c.professor_id = u.user_id "
                + "ORDER BY c.course_code";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                courses.add(createCourseFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting all courses: " + e.getMessage());
        }
        return courses;
    }

    /**
     * Gets all available (open) courses for registration.
     *
     * @return ArrayList of available courses
     */
    public ArrayList<Course> getAvailableCourses() {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, u.first_name || ' ' || u.last_name as professor_name, "
                + "(SELECT COUNT(*) FROM ENROLLMENTS e WHERE e.course_id = c.course_id) as enrolled_count "
                + "FROM COURSES c LEFT JOIN USERS u ON c.professor_id = u.user_id "
                + "WHERE c.is_open = 1 ORDER BY c.course_code";

        try {
            Connection conn = DatabaseConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Course course = createCourseFromResultSet(rs);
                // Only add if there are available seats
                if (course.hasAvailableSeats()) {
                    courses.add(course);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting available courses: " + e.getMessage());
        }
        return courses;
    }

    /**
     * Gets courses assigned to a specific professor.
     *
     * @param professorId the professor ID
     * @return ArrayList of courses assigned to the professor
     */
    public ArrayList<Course> getCoursesByProfessor(int professorId) {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, u.first_name || ' ' || u.last_name as professor_name, "
                + "(SELECT COUNT(*) FROM ENROLLMENTS e WHERE e.course_id = c.course_id) as enrolled_count "
                + "FROM COURSES c LEFT JOIN USERS u ON c.professor_id = u.user_id "
                + "WHERE c.professor_id = ? ORDER BY c.course_code";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, professorId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                courses.add(createCourseFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting courses by professor: " + e.getMessage());
        }
        return courses;
    }

    /**
     * Gets a course by ID.
     *
     * @param courseId the course ID
     * @return Course object if found, null otherwise
     */
    public Course getCourseById(int courseId) {
        String sql = "SELECT c.*, u.first_name || ' ' || u.last_name as professor_name, "
                + "(SELECT COUNT(*) FROM ENROLLMENTS e WHERE e.course_id = c.course_id) as enrolled_count "
                + "FROM COURSES c LEFT JOIN USERS u ON c.professor_id = u.user_id "
                + "WHERE c.course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, courseId);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return createCourseFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting course by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Adds a new course to the database.
     *
     * @param course the course to add
     * @return true if successful, false otherwise
     */
    public boolean addCourse(Course course) {
        String sql = "INSERT INTO COURSES (course_id, course_code, course_name, description, "
                + "credits, capacity, professor_id, is_open) "
                + "VALUES (course_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, course.getCourseCode());
            pstmt.setString(2, course.getCourseName());
            pstmt.setString(3, course.getDescription());
            pstmt.setInt(4, course.getCredits());
            pstmt.setInt(5, course.getCapacity());
            pstmt.setInt(6, course.getProfessorId());
            pstmt.setInt(7, course.isIsOpen() ? 1 : 0);

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error adding course: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates an existing course in the database.
     *
     * @param course the course to update
     * @return true if successful, false otherwise
     */
    public boolean updateCourse(Course course) {
        String sql = "UPDATE COURSES SET course_code = ?, course_name = ?, description = ?, "
                + "credits = ?, capacity = ?, professor_id = ?, is_open = ? WHERE course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, course.getCourseCode());
            pstmt.setString(2, course.getCourseName());
            pstmt.setString(3, course.getDescription());
            pstmt.setInt(4, course.getCredits());
            pstmt.setInt(5, course.getCapacity());
            pstmt.setInt(6, course.getProfessorId());
            pstmt.setInt(7, course.isIsOpen() ? 1 : 0);
            pstmt.setInt(8, course.getCourseId());

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error updating course: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a course from the database.
     *
     * @param courseId the course ID to delete
     * @return true if successful, false otherwise
     */
    public boolean deleteCourse(int courseId) {
        String sql = "DELETE FROM COURSES WHERE course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, courseId);

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting course: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a course code already exists.
     *
     * @param courseCode the course code to check
     * @return true if exists, false otherwise
     */
    public boolean courseCodeExists(String courseCode) {
        String sql = "SELECT COUNT(*) FROM COURSES WHERE course_code = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, courseCode);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking course code: " + e.getMessage());
        }
        return false;
    }

    /**
     * Creates a Course object from ResultSet.
     */
    private Course createCourseFromResultSet(ResultSet rs) throws SQLException {
        Course course = new Course();
        course.setCourseId(rs.getInt("course_id"));
        course.setCourseCode(rs.getString("course_code"));
        course.setCourseName(rs.getString("course_name"));
        course.setDescription(rs.getString("description"));
        course.setCredits(rs.getInt("credits"));
        course.setCapacity(rs.getInt("capacity"));
        course.setProfessorId(rs.getInt("professor_id"));
        course.setProfessorName(rs.getString("professor_name"));
        course.setIsOpen(rs.getInt("is_open") == 1);
        course.setEnrolledCount(rs.getInt("enrolled_count"));
        return course;
    }
}
