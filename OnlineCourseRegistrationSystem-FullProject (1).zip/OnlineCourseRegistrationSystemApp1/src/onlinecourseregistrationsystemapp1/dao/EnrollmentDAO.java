package onlinecourseregistrationsystemapp1.dao;

import onlinecourseregistrationsystemapp1.model.Course;
import onlinecourseregistrationsystemapp1.model.Enrollment;
import java.sql.*;
import java.util.ArrayList;

/**
 * Data Access Object for Enrollment operations.
 * Handles all database operations related to enrollments.
 */
public class EnrollmentDAO {

    /**
     * Gets all enrollments for a specific student.
     *
     * @param studentId the student ID
     * @return ArrayList of enrollments with course details
     */
    public ArrayList<Course> getEnrolledCourses(int studentId) {
        ArrayList<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, u.first_name || ' ' || u.last_name as professor_name, "
                + "(SELECT COUNT(*) FROM ENROLLMENTS e2 WHERE e2.course_id = c.course_id) as enrolled_count "
                + "FROM ENROLLMENTS e "
                + "JOIN COURSES c ON e.course_id = c.course_id "
                + "LEFT JOIN USERS u ON c.professor_id = u.user_id "
                + "WHERE e.student_id = ? ORDER BY c.course_code";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, studentId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));
                course.setCourseCode(rs.getString("course_code"));
                course.setCourseName(rs.getString("course_name"));
                course.setDescription(rs.getString("description"));
                course.setCredits(rs.getInt("credits"));
                course.setCapacity(rs.getInt("capacity"));
                course.setProfessorId(rs.getInt("professor_id"));
                course.setProfessorName(rs.getString("professor_name"));
                course.setIsOpen(rs.getInt("is_open") == 1);
                course.setEnrolledCount(rs.getInt("enrolled_count"));
                courses.add(course);
            }
        } catch (SQLException e) {
            System.err.println("Error getting enrolled courses: " + e.getMessage());
        }
        return courses;
    }

    /**
     * Gets all students enrolled in a specific course.
     *
     * @param courseId the course ID
     * @return ArrayList of enrollments with student details
     */
    public ArrayList<Enrollment> getEnrollmentsByCourse(int courseId) {
        ArrayList<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT e.*, u.first_name || ' ' || u.last_name as student_name "
                + "FROM ENROLLMENTS e "
                + "JOIN USERS u ON e.student_id = u.user_id "
                + "WHERE e.course_id = ? ORDER BY u.last_name";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, courseId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Enrollment enrollment = new Enrollment();
                enrollment.setEnrollmentId(rs.getInt("enrollment_id"));
                enrollment.setStudentId(rs.getInt("student_id"));
                enrollment.setCourseId(rs.getInt("course_id"));
                enrollment.setEnrollmentDate(rs.getDate("enrollment_date"));
                enrollment.setStudentName(rs.getString("student_name"));
                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.err.println("Error getting enrollments by course: " + e.getMessage());
        }
        return enrollments;
    }

    /**
     * Enrolls a student in a course.
     *
     * @param studentId the student ID
     * @param courseId the course ID
     * @return true if successful, false otherwise
     */
    public boolean enrollStudent(int studentId, int courseId) {
        // First check if already enrolled
        if (isEnrolled(studentId, courseId)) {
            System.err.println("Student is already enrolled in this course.");
            return false;
        }

        String sql = "INSERT INTO ENROLLMENTS (enrollment_id, student_id, course_id, enrollment_date) "
                + "VALUES (enrollment_seq.NEXTVAL, ?, ?, SYSDATE)";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error enrolling student: " + e.getMessage());
            return false;
        }
    }

    /**
     * Drops a student from a course.
     *
     * @param studentId the student ID
     * @param courseId the course ID
     * @return true if successful, false otherwise
     */
    public boolean dropCourse(int studentId, int courseId) {
        String sql = "DELETE FROM ENROLLMENTS WHERE student_id = ? AND course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);

            int result = pstmt.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            System.err.println("Error dropping course: " + e.getMessage());
            return false;
        }
    }

    /**
     * Checks if a student is enrolled in a specific course.
     *
     * @param studentId the student ID
     * @param courseId the course ID
     * @return true if enrolled, false otherwise
     */
    public boolean isEnrolled(int studentId, int courseId) {
        String sql = "SELECT COUNT(*) FROM ENROLLMENTS WHERE student_id = ? AND course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking enrollment: " + e.getMessage());
        }
        return false;
    }

    /**
     * Gets the count of enrolled students in a course.
     *
     * @param courseId the course ID
     * @return count of enrolled students
     */
    public int getEnrollmentCount(int courseId) {
        String sql = "SELECT COUNT(*) FROM ENROLLMENTS WHERE course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, courseId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error getting enrollment count: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Deletes all enrollments for a specific course.
     * Used when deleting a course.
     *
     * @param courseId the course ID
     * @return true if successful, false otherwise
     */
    public boolean deleteEnrollmentsByCourse(int courseId) {
        String sql = "DELETE FROM ENROLLMENTS WHERE course_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, courseId);

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error deleting enrollments by course: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes all enrollments for a specific student.
     * Used when deleting a student.
     *
     * @param studentId the student ID
     * @return true if successful, false otherwise
     */
    public boolean deleteEnrollmentsByStudent(int studentId) {
        String sql = "DELETE FROM ENROLLMENTS WHERE student_id = ?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, studentId);

            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("Error deleting enrollments by student: " + e.getMessage());
            return false;
        }
    }
}
