-- Online Course Registration System
-- Database Setup Script for Oracle
-- Run this script as system user

-- Drop existing tables (if needed for fresh start)
-- DROP TABLE ENROLLMENTS CASCADE CONSTRAINTS;
-- DROP TABLE COURSES CASCADE CONSTRAINTS;
-- DROP TABLE USERS CASCADE CONSTRAINTS;
-- DROP SEQUENCE user_seq;
-- DROP SEQUENCE course_seq;
-- DROP SEQUENCE enrollment_seq;

-- Create USERS table
CREATE TABLE USERS (
    user_id NUMBER PRIMARY KEY,
    username VARCHAR2(50) UNIQUE NOT NULL,
    password VARCHAR2(100) NOT NULL,
    role VARCHAR2(20) NOT NULL CHECK (role IN ('STUDENT', 'PROFESSOR', 'ADMIN')),
    first_name VARCHAR2(50) NOT NULL,
    last_name VARCHAR2(50) NOT NULL,
    email VARCHAR2(100)
);

-- Create COURSES table
CREATE TABLE COURSES (
    course_id NUMBER PRIMARY KEY,
    course_code VARCHAR2(20) UNIQUE NOT NULL,
    course_name VARCHAR2(100) NOT NULL,
    description VARCHAR2(500),
    credits NUMBER NOT NULL CHECK (credits > 0 AND credits < 5),
    capacity NUMBER NOT NULL,
    professor_id NUMBER REFERENCES USERS(user_id),
    is_open NUMBER(1) DEFAULT 1 CHECK (is_open IN (0, 1))
);

-- Create ENROLLMENTS table
CREATE TABLE ENROLLMENTS (
    enrollment_id NUMBER PRIMARY KEY,
    student_id NUMBER NOT NULL REFERENCES USERS(user_id),
    course_id NUMBER NOT NULL REFERENCES COURSES(course_id),
    enrollment_date DATE DEFAULT SYSDATE,
    CONSTRAINT unique_enrollment UNIQUE (student_id, course_id)
);

-- Create sequences for auto-increment
CREATE SEQUENCE user_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE course_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE enrollment_seq START WITH 1 INCREMENT BY 1;

-- Insert sample data

-- Insert Admin user
INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'admin', 'admin123', 'ADMIN', 'System', 'Administrator', 'admin@university.edu');

-- Insert Professor users
INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'prof1', 'prof123', 'PROFESSOR', 'Ahmed', 'Ali', 'ahmed.ali@university.edu');

INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'prof2', 'prof123', 'PROFESSOR', 'Sara', 'Mohammed', 'sara.mohammed@university.edu');

-- Insert Student users
INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'student1', 'student123', 'STUDENT', 'Fatima', 'Hassan', 'fatima.hassan@university.edu');

INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'student2', 'student123', 'STUDENT', 'Omar', 'Khalid', 'omar.khalid@university.edu');

INSERT INTO USERS (user_id, username, password, role, first_name, last_name, email)
VALUES (user_seq.NEXTVAL, 'student3', 'student123', 'STUDENT', 'Noura', 'Salem', 'noura.salem@university.edu');

-- Insert Courses (professor_id 2 is prof1, professor_id 3 is prof2)
INSERT INTO COURSES (course_id, course_code, course_name, description, credits, capacity, professor_id, is_open)
VALUES (course_seq.NEXTVAL, 'CS101', 'Introduction to Programming', 'Basic programming concepts using Java', 3, 30, 2, 1);

INSERT INTO COURSES (course_id, course_code, course_name, description, credits, capacity, professor_id, is_open)
VALUES (course_seq.NEXTVAL, 'CS201', 'Data Structures', 'Arrays, linked lists, trees, and graphs', 3, 25, 2, 1);

INSERT INTO COURSES (course_id, course_code, course_name, description, credits, capacity, professor_id, is_open)
VALUES (course_seq.NEXTVAL, 'CS301', 'Database Systems', 'Relational databases and SQL', 3, 25, 3, 1);

INSERT INTO COURSES (course_id, course_code, course_name, description, credits, capacity, professor_id, is_open)
VALUES (course_seq.NEXTVAL, 'CS313', 'Advanced Programming', 'JavaFX, JDBC, Collections, Generics', 4, 20, 3, 1);

-- Insert sample enrollments (student_id 4 is student1, 5 is student2, 6 is student3)
INSERT INTO ENROLLMENTS (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 4, 1, SYSDATE);

INSERT INTO ENROLLMENTS (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 4, 3, SYSDATE);

INSERT INTO ENROLLMENTS (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 5, 1, SYSDATE);

INSERT INTO ENROLLMENTS (enrollment_id, student_id, course_id, enrollment_date)
VALUES (enrollment_seq.NEXTVAL, 5, 2, SYSDATE);

COMMIT;

-- Verify data
SELECT * FROM USERS;
SELECT * FROM COURSES;
SELECT * FROM ENROLLMENTS;
