package onlinecourseregistrationsystemapp1;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import onlinecourseregistrationsystemapp1.dao.DatabaseConnection;

/**
 * Main Application class for Online Course Registration System.
 * CS313 Advanced Programming Language - Term Project.
 */
public class OnlineCourseRegistrationSystemApp1 extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        // Load the Login screen
        Parent root = FXMLLoader.load(getClass().getResource("view/Login.fxml"));

        Scene scene = new Scene(root);

        stage.setTitle("Login - Online Course Registration System");
        stage.setScene(scene);
        stage.setResizable(true);
        stage.centerOnScreen();
        stage.show();
    }

    @Override
    public void stop() throws Exception {
        // Close database connection when application exits
        DatabaseConnection.closeConnection();
        super.stop();
    }

    /**
     * Main method - entry point of the application.
     *1
     * @param args command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
